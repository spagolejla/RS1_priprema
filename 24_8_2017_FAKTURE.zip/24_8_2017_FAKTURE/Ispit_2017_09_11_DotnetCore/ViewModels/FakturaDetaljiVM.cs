﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ispit_2017_09_11_DotnetCore.ViewModels
{
    public class FakturaDetaljiVM
    {
		public string Klijent { get; set; }
		public string Datum { get; set; }
		public int FakturaID { get; set; }
    }
}
