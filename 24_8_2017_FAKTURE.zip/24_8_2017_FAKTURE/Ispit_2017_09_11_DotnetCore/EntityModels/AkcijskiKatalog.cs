﻿using System;

namespace Ispit_2017_09_11_DotnetCore.EntityModels
{
    public class AkcijskiKatalog
    {
        public int Id { get; set; }
        public string Opis{ get; set; }
        public DateTime Pocetak{ get; set; }
        public DateTime Kraj{ get; set; }
     
    }
}
