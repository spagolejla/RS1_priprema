﻿namespace Ispit_2017_09_11_DotnetCore.EntityModels
{
    public class Klijent
    {
        public int Id { get; set; }
        public string ImePrezime { get; set; }
    }
}
