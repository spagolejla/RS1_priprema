﻿namespace Ispit_2017_09_11_DotnetCore.EntityModels
{
    public class Proizvod
    {
        public int Id { get; set; }
        public string Naziv { get; set; }
        public float Cijena { get; set; }
    }
}
