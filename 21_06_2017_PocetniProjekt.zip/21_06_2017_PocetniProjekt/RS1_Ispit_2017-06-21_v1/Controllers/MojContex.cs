﻿namespace RS1_Ispit_2017_06_21_v1.Controllers
{
	internal class MojContex
	{
	}
}